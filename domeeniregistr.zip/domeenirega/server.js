const http = require('http');
const cors = require('cors');

const mysql = require('mysql2');
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'Passw0rd',
    database: 'domeen123',
});

connection.connect((error) => {
    if (error) {
        console.log('Error connecting to the MySQL Database');
        return;
    }
    console.log('Connection established sucessfully');
});

const server = http.createServer(function (req, res) {
    // Set up CORS headers
    // cors()(req, res, () => {});
    res.setHeader("Access-Control-Allow-Origin", "*")
    res.setHeader("Access-Control-Allow-Methods", "GET, POST")
    res.setHeader("Access-Control-Allow-Headers", "content-type")

    if (req.method === 'POST') {
        var body = '';

        req.on('data', function (data) {
            body += data;
        });

        req.on('end', function () {
            let receivedData;
            try {
                receivedData = JSON.parse(body);
                console.log('Received data from client:', receivedData);
                for (const key in receivedData) {
                    receivedData[key]=mysql_real_escape_string(receivedData[key])
                }
                connection.query(`
                insert into tellimused (
                    first_name, 
                    last_name, 
                    email, phone,
                    firm_name,
                    registrikood
                ) values (
                    '${receivedData.firstName}',
                    '${receivedData.lastName}',
                    '${receivedData.email}', 
                    '${receivedData.phoneNumber}',
                    '${receivedData.firmaNimi}', 
                    '${receivedData.registrikood}');`, 
                    err => {
                    console.log(err)
                })
                // Process the received data as needed
            } catch (err) {
                console.error('Failed to parse JSON:', err);
                res.writeHead(400, { 'Content-Type': 'text/plain' });
                res.end('Invalid JSON');
                return;
            }

            // Send a response back to the client
            res.statusCode = 200;
            res.setHeader('Content-Type', 'application/json');
            res.end(JSON.stringify({ message: 'Data received successfully' }));
        });
    }
    else if (req.method === "OPTIONS") {
        res.end()
    }
    else {
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end('Not Found');

    }
});

// Start the server
server.listen(3000, () => {
    console.log('Server is running on port 3000');
});

function mysql_real_escape_string (str) {
    return str.replace(/[\0\x08\x09\x1a\n\r"'\\\%]/g, function (char) {
        switch (char) {
            case "\0":
                return "\\0";
            case "\x08":
                return "\\b";
            case "\x09":
                return "\\t";
            case "\x1a":
                return "\\z";
            case "\n":
                return "\\n";
            case "\r":
                return "\\r";
            case "\"":
            case "'":
            case "\\":
            case "%":
                return "\\"+char; // prepends a backslash to backslash, percent,
                                  // and double/single quotes
            default:
                return char;
        }
    });
}